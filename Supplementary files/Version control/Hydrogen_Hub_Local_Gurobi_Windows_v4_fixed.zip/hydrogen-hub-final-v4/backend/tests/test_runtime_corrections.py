from __future__ import annotations

import hashlib
from pathlib import Path

from backend.app.services.input_adapter import adapt, stage_run
from backend.app.services.runner_entry import (
    _required_max_demand_big_m,
    _runtime_solver_source,
)
from backend.app.services.smoke_test import _scenario
from backend.tests.conftest import SOLVER_DIR


def _staged_smoke_inputs(tmp_path: Path, baseline) -> Path:
    staged, resolved = adapt(baseline, _scenario())
    stage_run(
        baseline,
        staged,
        _scenario(),
        resolved,
        run_id="big-m-regression",
        run_dir=tmp_path,
        solver_module=SOLVER_DIR / "HSC_operational.py",
        baseline_manifest=SOLVER_DIR / "manifest.sha256",
    )
    return tmp_path / "inputs"


def test_smoke_data_requires_more_than_original_big_m(tmp_path: Path, baseline):
    inputs = _staged_smoke_inputs(tmp_path, baseline)
    assert _required_max_demand_big_m(inputs) > 10_000


def test_runtime_big_m_patch_preserves_solver_file(tmp_path: Path, baseline):
    inputs = _staged_smoke_inputs(tmp_path, baseline)
    solver = inputs / "HSC_operational.py"
    before = hashlib.sha256(solver.read_bytes()).hexdigest()

    source, correction = _runtime_solver_source(inputs)

    assert correction is not None
    assert correction["applied_value"] > correction["original_value"]
    assert "initialize=1e4" not in source
    assert f"initialize={correction['applied_value']}" in source
    assert hashlib.sha256(solver.read_bytes()).hexdigest() == before
