# v4 licensed-smoke feasibility fix

The Gurobi licence is loading correctly. The failure below is a mathematical
infeasibility in the staged model, not a licence problem:

```text
Academic license ... registered
Licensed smoke result: status=failed termination=infeasible
```

## Root cause

The preserved solver hard-codes the scalar big-M used by the maximum-demand
billing constraints as `10,000`.

For the bundled Johor power data, bus `B59` has a load factor of approximately
`0.074202`. At the 6,000-unit system-demand hour, its unshifted bus demand is
approximately `445.21`. The maximum-demand block permits adjusted demand up to
120% and applies a `50` multiplier. The associated bound can therefore require
more than `26,700`, which cannot fit under a big-M of `10,000`. Even the 80%
lower adjustment at that hour implies approximately `17,808`, so the
contradiction is not optional and Gurobi correctly proves infeasibility.

This is separate from the v3 H2-tank issue. Version 3 removed `HT1`-`HT5`, but
its licensed solve then exposed this second independent contradiction.

## Correction

- `backend/solver/HSC_operational.py` remains byte-for-byte unchanged.
- `runner_entry.py` reads the staged power data and derives a safe maximum-demand
  big-M with a bounded safety margin. For the bundled data it applies `33,391`.
- The correction is compiled in memory for the isolated run only; the protected
  solver file on disk and its SHA-256 manifest are untouched.
- Every run log records a `runtime_correction_applied` marker and completed run
  summaries disclose the correction as a warning.
- The licensed smoke failure path now prints the first IIS constraint names if
  another independent infeasibility is ever found.
- Regression tests verify that the bundled smoke data needs more than `10,000`
  and that the runtime correction does not modify the staged solver file.

## Run the corrected setup

Extract this release into a new folder, copy only your private
`secrets\gurobi.lic` into it, open Docker Desktop, and run:

```powershell
PowerShell -NoProfile -ExecutionPolicy Bypass -File .\Setup-Hydrogen-Hub.ps1
```

Require both:

```text
LICENSED SMOKE SOLVE PASSED
SETUP COMPLETE
```

Do not use `docker compose down -v`; that deletes the persistent results volume.
