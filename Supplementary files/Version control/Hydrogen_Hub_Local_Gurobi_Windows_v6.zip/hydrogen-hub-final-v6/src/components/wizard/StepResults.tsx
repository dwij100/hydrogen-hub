import { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { AlertTriangle, Download, Info, Loader2 } from 'lucide-react';
import {
  Bar,
  CartesianGrid,
  ComposedChart,
  Legend,
  Line,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { useHydrogenProject } from '@/context/HydrogenProjectContext';
import { useSolverRun } from '@/context/SolverRunContext';
import { SOLVER_NOT_CONNECTED_MESSAGE } from '@/lib/solver/client';
import {
  ACTIVE_RUN_STATES,
  RUN_STATE_LABELS,
  type ChartCategory,
  type ResultChartGroup,
  type ResultTable,
} from '@/lib/solver/types';

const CATEGORY_LABELS: Record<ChartCategory, string> = {
  production: 'Hydrogen production',
  flows: 'Hydrogen flows',
  utilization: 'Infrastructure utilization',
  storage: 'Storage',
  transport: 'Transport',
};

const CATEGORY_ORDER: ChartCategory[] = [
  'production',
  'flows',
  'utilization',
  'storage',
  'transport',
];

const SERIES_COLORS = [
  'hsl(var(--primary))',
  'hsl(var(--chart-2, 173 58% 39%))',
  'hsl(var(--chart-3, 197 37% 24%))',
  'hsl(var(--chart-4, 43 74% 66%))',
  'hsl(var(--chart-5, 27 87% 67%))',
];

const MODEL_HOURS = Array.from({ length: 24 }, (_, index) => index + 1);
const X_TICKS = [1, 4, 8, 12, 16, 20, 24];

export function toChartData(group: ResultChartGroup) {
  // Pre-create the complete numeric horizon. Values remain undefined until the
  // backend supplies them, so genuine missing solver values render as gaps.
  const byX = new Map<number, Record<string, number>>(
    MODEL_HOURS.map((hour) => [hour, { t: hour }]),
  );
  group.series.forEach((series) => {
    series.points.forEach((point) => {
      const hour = Number(point.t);
      if (!Number.isFinite(hour)) return;
      const existing = byX.get(hour) ?? { t: hour };
      existing[series.key] = point.value;
      byX.set(hour, existing);
    });
  });
  return Array.from(byX.values()).sort((a, b) => a.t - b.t);
}

function inferChartType(group: ResultChartGroup): 'line' | 'step' | 'bar' {
  if (group.chartType) return group.chartType;
  if (/charge|discharge|load|unload|generation|outflow/i.test(group.label)) return 'bar';
  if (/state|inventory|transit|demand/i.test(group.label)) return 'step';
  return 'line';
}

function formatChartValue(value: number): string {
  const absolute = Math.abs(value);
  if (absolute >= 1000) return value.toLocaleString(undefined, { maximumFractionDigits: 1 });
  if (absolute >= 1) return value.toLocaleString(undefined, { maximumFractionDigits: 3 });
  if (absolute === 0) return '0';
  return value.toLocaleString(undefined, { maximumSignificantDigits: 4 });
}

function download(filename: string, content: string, type: string) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}

function tableToCsv(table: ResultTable): string {
  const escape = (cell: unknown) => {
    const value = cell === null || cell === undefined ? '' : String(cell);
    return /[",\n]/.test(value) ? `"${value.replace(/"/g, '""')}"` : value;
  };
  return [table.columns.map(escape).join(','), ...table.rows.map((r) => r.map(escape).join(','))]
    .join('\n');
}

function ChartGroup({ group }: { group: ResultChartGroup }) {
  const data = useMemo(() => toChartData(group), [group]);
  const chartType = inferChartType(group);
  const yAxisMode = group.yAxisMode ?? 'auto';
  const values = group.series.flatMap((series) => series.points.map((point) => point.value));
  const hasNegative = values.some((value) => value < 0);
  const hasData = values.length > 0;

  if (!hasData) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-base">{group.label}</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">
            The backend returned no data points for this series.
          </p>
        </CardContent>
      </Card>
    );
  }

  const minimum = Math.min(...values);
  const maximum = Math.max(...values);
  const span = Math.max(maximum - minimum, Math.abs(maximum), Math.abs(minimum), 1);
  const padding = span * 0.05;
  const yDomain: [number, number] =
    yAxisMode === 'fraction' || yAxisMode === 'binary'
      ? [0, 1]
      : hasNegative
        ? [Math.min(0, minimum - padding), Math.max(0, maximum + padding)]
        : [0, Math.max(1, maximum + padding)];
  const yTicks = yAxisMode === 'binary'
    ? [0, 1]
    : yAxisMode === 'fraction'
      ? [0, 0.25, 0.5, 0.75, 1]
      : undefined;

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base">
          {group.label}
          {group.unit ? ` (${group.unit})` : ''}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {group.description && (
          <p className="mb-3 text-xs leading-relaxed text-muted-foreground">{group.description}</p>
        )}
        <div className="h-72 w-full" data-chart-type={chartType}>
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={data} margin={{ top: 8, right: 18, left: 8, bottom: 28 }}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
              <XAxis
                dataKey="t"
                type="number"
                domain={[1, 24]}
                ticks={X_TICKS}
                allowDecimals={false}
                tick={{ fontSize: 12 }}
                label={{ value: group.xLabel || 'Hour (1-24)', position: 'insideBottom', offset: -18 }}
              />
              <YAxis
                domain={yDomain}
                ticks={yTicks}
                allowDecimals={yAxisMode !== 'binary'}
                tick={{ fontSize: 12 }}
                tickFormatter={yAxisMode === 'fraction'
                  ? (value) => `${Math.round(Number(value) * 100)}%`
                  : (value) => formatChartValue(Number(value))}
                width={72}
              />
              {hasNegative && <ReferenceLine y={0} stroke="hsl(var(--muted-foreground))" />}
              <Tooltip
                labelFormatter={(label) => `Hour ${label}`}
                formatter={(value, name) => {
                  const numeric = Number(value);
                  const formatted = yAxisMode === 'fraction'
                    ? `${(numeric * 100).toLocaleString(undefined, { maximumFractionDigits: 1 })}%`
                    : formatChartValue(numeric);
                  return [formatted, name];
                }}
              />
              <Legend wrapperStyle={{ fontSize: 11, paddingTop: 8 }} />
              {group.series.map((series, index) => {
                const color = SERIES_COLORS[index % SERIES_COLORS.length];
                if (chartType === 'bar') {
                  return (
                    <Bar
                      key={series.key}
                      dataKey={series.key}
                      name={series.label}
                      fill={color}
                      stackId="hourly-total"
                      isAnimationActive={false}
                    />
                  );
                }
                return (
                  <Line
                    key={series.key}
                    type={chartType === 'step' ? 'stepAfter' : 'linear'}
                    dataKey={series.key}
                    name={series.label}
                    stroke={color}
                    dot={false}
                    connectNulls={false}
                    strokeWidth={2}
                    isAnimationActive={false}
                  />
                );
              })}
            </ComposedChart>
          </ResponsiveContainer>
        </div>
        {chartType === 'bar' && (
          <p className="mt-1 text-[11px] text-muted-foreground">
            Stacked bars show total hourly activity; an absent bar represents zero activity.
          </p>
        )}
      </CardContent>
    </Card>
  );
}

function ResultTableView({ table }: { table: ResultTable }) {
  const [filter, setFilter] = useState('');
  const rows = useMemo(() => {
    if (!filter.trim()) return table.rows;
    const needle = filter.toLowerCase();
    return table.rows.filter((row) =>
      row.some((cell) => String(cell ?? '').toLowerCase().includes(needle)),
    );
  }, [filter, table.rows]);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-4 space-y-0">
        <CardTitle className="text-base">{table.label}</CardTitle>
        <div className="flex items-center gap-2">
          <Input
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            placeholder="Filter rows"
            className="h-9 w-40"
            aria-label={`Filter ${table.label}`}
          />
          <Button
            variant="outline"
            size="sm"
            onClick={() => download(`${table.key}.csv`, tableToCsv(table), 'text/csv')}
          >
            <Download className="mr-2 h-4 w-4" /> CSV
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {table.truncated && (
          <p className="mb-3 text-xs text-muted-foreground">
            Showing {table.rows.length.toLocaleString()} of {table.total_rows.toLocaleString()} non-zero rows.
            Use the downloaded JSON or API variable filter for additional pages.
          </p>
        )}
        {table.rows.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            The backend returned no rows for this table.
          </p>
        ) : (
          <div className="max-h-96 overflow-auto">
            <table className="w-full text-sm">
              <thead className="sticky top-0 bg-background">
                <tr className="border-b">
                  {table.columns.map((column) => (
                    <th key={column} className="text-left py-2 px-3 font-medium">
                      {column}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rows.map((row, index) => (
                  <tr key={index} className="border-b">
                    {row.map((cell, cellIndex) => (
                      <td key={cellIndex} className="py-2 px-3">
                        {cell === null || cell === undefined ? '–' : String(cell)}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export function StepResults() {
  const { project } = useHydrogenProject();
  const {
    backendConfigured,
    run,
    results,
    isStale,
    isPolling,
    isLoadingResults,
    runError,
    resultsError,
    loadRun,
  } = useSolverRun();
  const [searchParams] = useSearchParams();
  const deepLinkedRunId = searchParams.get('run');

  // Deep link: /hydrogen/setup?step=6&run=<id>
  useEffect(() => {
    if (!backendConfigured || !deepLinkedRunId) return;
    if (run?.run_id === deepLinkedRunId) return;
    void loadRun(deepLinkedRunId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [deepLinkedRunId, backendConfigured]);

  const charts = results?.charts ?? [];
  const tables = results?.tables ?? [];
  const active = run ? ACTIVE_RUN_STATES.includes(run.status) : false;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground">Optimization Results</h2>
        <p className="text-muted-foreground mt-1">
          Results returned by the local Gurobi optimization service
        </p>
      </div>

      {!backendConfigured && (
        <Alert>
          <Info className="h-4 w-4" />
          <AlertDescription>{SOLVER_NOT_CONNECTED_MESSAGE}</AlertDescription>
        </Alert>
      )}

      {backendConfigured && !run && !runError && (
        <Alert>
          <Info className="h-4 w-4" />
          <AlertDescription>
            No optimization run for this project yet. Start one from the Submit step.
          </AlertDescription>
        </Alert>
      )}

      {runError && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Run unavailable</AlertTitle>
          <AlertDescription>{runError}</AlertDescription>
        </Alert>
      )}

      {isStale && run && (
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            Solver inputs have changed since this run — the results below are out of date.
          </AlertDescription>
        </Alert>
      )}

      {run && (
        <Card>
          <CardHeader>
            <CardTitle>Run status</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div>
              <span className="text-muted-foreground">Status</span>
              <div className="font-medium flex items-center gap-2">
                {(active || isPolling) && <Loader2 className="h-4 w-4 animate-spin" />}
                <Badge variant={run.status === 'completed' ? 'secondary' : 'outline'}>
                  {RUN_STATE_LABELS[run.status]}
                </Badge>
              </div>
            </div>
            <div>
              <span className="text-muted-foreground">Run ID</span>
              <p className="font-medium break-all">{run.run_id}</p>
            </div>
            <div>
              <span className="text-muted-foreground">Solver</span>
              <p className="font-medium">{run.solver_name ?? results?.solver_name ?? '–'}</p>
            </div>
            <div>
              <span className="text-muted-foreground">Termination condition</span>
              <p className="font-medium">
                {run.termination_condition ?? results?.termination_condition ?? '–'}
              </p>
            </div>
            <div>
              <span className="text-muted-foreground">
                {run.objective_label ?? results?.objective_label ?? 'Objective value'}
              </span>
              <p className="font-medium">
                {run.objective_value ?? results?.objective_value ?? '–'} {results?.objective_unit ?? ''}
              </p>
            </div>
            <div>
              <span className="text-muted-foreground">Dataset</span>
              <p className="font-medium">
                {run.dataset?.name ?? results?.dataset?.name ?? project.dataset.id}
              </p>
            </div>
            {run.message && (
              <div className="md:col-span-3">
                <span className="text-muted-foreground">Message</span>
                <p className="font-medium">{run.message}</p>
              </div>
            )}
            {run.error && (
              <div className="md:col-span-3">
                <Alert variant="destructive">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>{run.error}</AlertDescription>
                </Alert>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {run && run.status !== 'completed' && !active && (
        <Alert variant={run.status === 'cancelled' ? 'default' : 'destructive'}>
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>{RUN_STATE_LABELS[run.status]}</AlertTitle>
          <AlertDescription>
            This run did not produce an optimal solution, so no results are shown.
          </AlertDescription>
        </Alert>
      )}

      {isLoadingResults && (
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading results…
        </div>
      )}

      {resultsError && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Results unavailable</AlertTitle>
          <AlertDescription>{resultsError}</AlertDescription>
        </Alert>
      )}

      {results && run?.status === 'completed' && (
        <>
          <div className="flex justify-end">
            <Button
              variant="outline"
              size="sm"
              onClick={() =>
                download(
                  `run-${results.run_id}.json`,
                  JSON.stringify(results, null, 2),
                  'application/json',
                )
              }
            >
              <Download className="mr-2 h-4 w-4" /> Download JSON
            </Button>
          </div>

          {results.input_summary && Object.keys(results.input_summary).length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Input summary</CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                {Object.entries(results.input_summary).map(([key, value]) => (
                  <div key={key}>
                    <span className="text-muted-foreground">{key}</span>
                    <p className="font-medium">{value === null ? '–' : String(value)}</p>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {charts.length === 0 && tables.length === 0 && (
            <Alert>
              <Info className="h-4 w-4" />
              <AlertDescription>
                The run completed but returned no result series or tables.
              </AlertDescription>
            </Alert>
          )}

          {CATEGORY_ORDER.filter((category) =>
            charts.some((group) => group.category === category),
          ).map((category) => (
            <div key={category} className="space-y-4">
              <h3 className="text-lg font-semibold">{CATEGORY_LABELS[category]}</h3>
              {charts
                .filter((group) => group.category === category)
                .map((group) => (
                  <ChartGroup key={group.key} group={group} />
                ))}
            </div>
          ))}

          {tables.length > 0 && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Result tables</h3>
              {tables.map((table) => (
                <ResultTableView key={table.key} table={table} />
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}
