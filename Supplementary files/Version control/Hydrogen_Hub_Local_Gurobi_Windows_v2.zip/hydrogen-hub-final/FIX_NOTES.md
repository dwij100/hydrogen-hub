# Setup verification fix

This release fixes the setup failure:

```text
FileNotFoundError: /srv/hydrogen/src/lib/solver/types.ts
```

## Cause

The backend contract test correctly compares the frontend `RunState` union
with the backend `RunStatus` enum, but the backend Docker image previously
copied only the `backend/` directory. The required frontend contract file was
present in the project but absent from the test container.

## Corrections

- The backend image now includes `src/lib/solver/types.ts` at the exact path
  expected by the contract test.
- Setup disables pytest's cache provider because `/srv/hydrogen` is read-only
  to the non-root container user.
- HTTP 422 responses use the current Starlette constant, removing the displayed
  deprecation warning.

The solver source and all 27 bundled Johor data files remain unchanged and
pass the included SHA-256 manifest.

## Run the corrected setup

Extract this release into a new folder, copy only your private
`secrets\gurobi.lic` into it, open Docker Desktop, then run:

```powershell
PowerShell -NoProfile -ExecutionPolicy Bypass -File .\Setup-Hydrogen-Hub.ps1
```

The failed temporary test container and Docker network from the earlier attempt
do not need manual removal. Docker Compose can reuse them safely.
