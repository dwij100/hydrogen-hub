"""Subprocess entry point: build and solve the preserved model, emit JSON.

Invoked as `python -m backend.app.services.runner_entry <job_dir> <out.json>`
with the process working directory set to the job directory, because the
unchanged solver reads its 11 tables with fixed relative filenames at import
time. It is imported as a module so its `if __name__ == "__main__":` block —
which calls plt.show() — never executes.
"""

from __future__ import annotations

import gzip
import importlib.util
import json
import os
import resource
import sys
import time
from pathlib import Path


def _load_solver(job_dir: Path):
    module_path = job_dir / "HSC_operational.py"
    spec = importlib.util.spec_from_file_location("hsc_operational_run", module_path)
    if spec is None or spec.loader is None:
        raise RuntimeError("solver module could not be loaded")
    module = importlib.util.module_from_spec(spec)
    # Name is not "__main__", so the plotting block at the bottom is skipped.
    spec.loader.exec_module(module)
    return module


def main() -> int:
    os.environ.setdefault("MPLBACKEND", "Agg")
    job_dir = Path(sys.argv[1]).resolve()
    out_path = Path(sys.argv[2]).resolve()
    solver_name = os.environ.get("SOLVER_NAME", "gurobi")
    time_limit = int(os.environ.get("SOLVE_TIMEOUT_SECONDS", "21600"))
    tolerance = float(os.environ.get("ZERO_TOLERANCE", "1e-9"))

    os.chdir(job_dir)
    sys.path.insert(0, str(job_dir))
    sys.path.insert(0, str(Path(__file__).resolve().parents[3]))

    from backend.app.services.result_serializer import serialize_model, serialize_sets

    payload: dict[str, object] = {"stage": "building"}
    started = time.time()
    try:
        import pyomo.environ as pyo

        module = _load_solver(job_dir)
        model = module.build_model()
        build_seconds = time.time() - started

        payload["stage"] = "solving"
        opt = pyo.SolverFactory(solver_name)
        if not opt.available(exception_flag=False):
            raise RuntimeError(
                f"solver '{solver_name}' is not available in this environment"
            )
        opt.options["TimeLimit" if solver_name == "gurobi" else "timelimit"] = time_limit

        solve_started = time.time()
        results = opt.solve(model, tee=False, load_solutions=False)
        solve_seconds = time.time() - solve_started

        status = str(results.solver.status)
        termination = str(results.solver.termination_condition)
        objective_value = None
        serialized: dict[str, object] = {"families": {}, "missing_variables": []}
        sets: dict[str, object] = {}

        if termination in {"optimal", "feasible", "maxTimeLimit", "maxTimeLimitWithSolution", "other"} and getattr(
            results.solver, "status", None
        ) is not None:
            try:
                model.solutions.load_from(results)
                payload["stage"] = "serializing"
                serialized = serialize_model(model, tolerance)
                sets = serialize_sets(model)
                objective = next(
                    model.component_data_objects(pyo.Objective, active=True), None
                )
                if objective is not None:
                    objective_value = float(pyo.value(objective))
            except Exception as exc:  # noqa: BLE001
                payload["load_warning"] = f"no solution could be loaded: {exc.__class__.__name__}"

        peak_kb = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        payload.update(
            {
                "stage": "completed",
                "solver_status": status,
                "termination_condition": termination,
                "objective_name": "Total hydrogen imbalance",
                "objective_unit": "model hydrogen units",
                "objective_value": objective_value,
                "num_variables": int(model.nvariables()),
                "num_constraints": int(model.nconstraints()),
                "build_seconds": build_seconds,
                "solve_seconds": solve_seconds,
                "peak_memory_mb": peak_kb / 1024.0,
                "sets": sets,
                "results": serialized,
            }
        )
    except Exception as exc:  # noqa: BLE001 - the parent maps this to a safe code
        payload.update(
            {
                "stage": "failed",
                "error_type": exc.__class__.__name__,
                "error_detail": str(exc),
            }
        )

    with gzip.open(out_path, "wt", encoding="utf-8") as handle:
        json.dump(payload, handle)
    return 0 if payload.get("stage") == "completed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
