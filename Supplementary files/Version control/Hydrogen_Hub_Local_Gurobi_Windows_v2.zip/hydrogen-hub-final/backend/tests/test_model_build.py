from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

import pytest

from backend.app.services import input_adapter
from backend.tests.conftest import SOLVER_DIR

pytest.importorskip("pyomo.environ", reason="Pyomo is installed in the production image")


def test_adapted_inputs_build_the_preserved_model(tmp_path: Path, baseline, scenario):
    staged, resolved = input_adapter.adapt(baseline, scenario)
    input_adapter.stage_run(
        baseline, staged, scenario, resolved, run_id="build", run_dir=tmp_path,
        solver_module=SOLVER_DIR / "HSC_operational.py",
        baseline_manifest=SOLVER_DIR / "manifest.sha256",
    )
    script = (
        "import importlib.util;"
        "s=importlib.util.spec_from_file_location('hsc','HSC_operational.py');"
        "m=importlib.util.module_from_spec(s);s.loader.exec_module(m);"
        "model=m.build_model();print(model.nvariables(),model.nconstraints())"
    )
    result = subprocess.run(
        [sys.executable, "-c", script], cwd=tmp_path / "inputs",
        env={**os.environ, "MPLBACKEND": "Agg"}, capture_output=True, text=True, check=False,
    )
    assert result.returncode == 0, result.stderr[-3000:]
    variables, constraints = [int(value) for value in result.stdout.split()[-2:]]
    assert variables > 2000 and constraints > 2000
