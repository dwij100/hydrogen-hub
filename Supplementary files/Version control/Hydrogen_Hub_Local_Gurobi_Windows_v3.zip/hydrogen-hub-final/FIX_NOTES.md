# v3 feasibility fix

This release fixes the v2 runtime failure:

```text
Gurobi did not return an optimal solution.
Termination: infeasible
```

## Cause

Version 2 carried five baseline H2 tanks (`HT1`–`HT5`) into every reduced
scenario even though version 1 has no H2-storage control. The preserved model
fixes each tank at 30% state of charge at both hour 1 and hour 24 and applies
hourly leakage. A POM1-only scenario has no external H2 source capable of
replacing that loss, so the staged equations are contradictory.

The displayed Pyomo `rw_path` deprecation warning did not cause the failure.
It appeared because v2 suppressed the Gurobi console output while leaving
Pyomo warnings visible.

## Corrections

- Isolated run inputs exclude `HT1`–`HT5`; the original storage CSV remains
  unchanged and fixed baseline electrical storage remains staged.
- Resolved configurations and manifests record the retained and excluded
  storage units.
- Run logs now record model build, solve, termination and child-process exit.
- Infeasible runs generate Gurobi IIS summary and `.ilp` diagnostics.
- Setup now performs the exact licensed POM1 smoke solve and cannot print
  `SETUP COMPLETE` unless Gurobi returns `optimal` with a real objective value.
- The earlier Docker contract-test hotfix remains included.

The solver source and all 27 bundled Johor data files remain unchanged and
pass the included SHA-256 manifest.

## Run the corrected setup

Extract v3 into a new folder, copy only your private `secrets\gurobi.lic` into
it, open Docker Desktop, then run:

```powershell
PowerShell -NoProfile -ExecutionPolicy Bypass -File .\Setup-Hydrogen-Hub.ps1
```

Require both `LICENSED SMOKE SOLVE PASSED` and `SETUP COMPLETE`. The existing
Docker network and persistent result volume can be reused safely; do not run
`docker compose down -v`.
