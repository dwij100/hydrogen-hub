Place your private full Gurobi licence in this folder with the exact filename:

gurobi.lic

Do not share, commit, upload, or paste the licence contents anywhere.
