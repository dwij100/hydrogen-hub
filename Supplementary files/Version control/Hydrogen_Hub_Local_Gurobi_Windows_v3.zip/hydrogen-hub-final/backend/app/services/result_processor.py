"""Convert persisted raw Pyomo records into plot-ready and filterable API results."""

from __future__ import annotations

import json
from collections import defaultdict
from typing import Any

from ..schemas import (
    DatasetSummary,
    ResultChartGroup,
    ResultSeries,
    ResultSeriesPoint,
    ResultsResponse,
    ResultTable,
    ScenarioConfig,
)
from .input_adapter import CONSUMER_MAP

CHART_VARIABLES: dict[str, tuple[str, str]] = {
    "process_res": ("utilization", "Plant processing rates"),
    "plant_inven": ("utilization", "Plant inventories"),
    "h2_inven": ("flows", "Hydrogen inventory by node"),
    "pipe_out": ("flows", "Hydrogen pipeline outflow"),
    "H2_charge": ("storage", "System hydrogen charging"),
    "H2_discharge": ("storage", "System hydrogen discharging"),
    "soc": ("storage", "Storage state of charge"),
    "charge": ("storage", "Storage charging"),
    "discharge": ("storage", "Storage discharging"),
    "v_soc": ("transport", "Vehicle state of charge or load"),
    "vx_transit": ("transport", "Vehicles in transit"),
    "rw_load": ("transport", "Railway loading"),
    "rw_unload": ("transport", "Railway unloading"),
    "rw_soc": ("transport", "Railway load state"),
    "pv_gen": ("production", "Solar generation"),
    "H2_SF": ("production", "Solar-powered hydrogen production"),
    "gen_elec": ("utilization", "Electrical generation"),
    "flow_elec": ("flows", "Electrical line flow"),
}


def _iter_variables(payload: dict[str, Any]):
    for family, variables in payload.get("results", {}).get("families", {}).items():
        for name, block in variables.items():
            yield family, name, block


def _series_for(block: dict[str, Any], limit: int = 20) -> list[ResultSeries]:
    indexes = list(block.get("index_names", []))
    if "hour" not in indexes:
        return []
    hour_position = indexes.index("hour")
    entity_positions = [position for position, name in enumerate(indexes) if name != "hour"]
    points: dict[str, list[ResultSeriesPoint]] = defaultdict(list)
    magnitudes: dict[str, float] = defaultdict(float)
    for record in block.get("records", []):
        keys = record.get("keys", [])
        if hour_position >= len(keys):
            continue
        entities = [
            f"{indexes[position]}={keys[position]}"
            for position in entity_positions
            if position < len(keys)
        ]
        label = ", ".join(entities) if entities else block.get("title", block.get("series_id", "Series"))
        value = float(record["value"])
        points[label].append(ResultSeriesPoint(t=keys[hour_position], value=value))
        magnitudes[label] += abs(value)
    selected = sorted(points, key=lambda key: magnitudes[key], reverse=True)[:limit]
    return [
        ResultSeries(
            key=f"{block.get('series_id', 'series')}:{index}",
            label=label,
            unit=str(block.get("unit", "model units")),
            points=sorted(points[label], key=lambda point: int(point.t)),
        )
        for index, label in enumerate(selected)
    ]


def _demand_chart(scenario: ScenarioConfig) -> ResultChartGroup:
    series = []
    for item in scenario.consumers:
        node = CONSUMER_MAP[item.consumer_id]
        hourly = float(item.demand_kg_per_day) / 24.0
        series.append(
            ResultSeries(
                key=f"demand:{node}",
                label=node,
                unit="kg H2/hour",
                points=[ResultSeriesPoint(t=hour, value=hourly) for hour in range(1, 25)],
            )
        )
    return ResultChartGroup(
        key="submitted-hydrogen-demand",
        label="Submitted hydrogen demand",
        category="flows",
        xLabel="Hour (1-24)",
        unit="kg H2/hour",
        series=series,
        description=(
            "The unchanged model consumes one 24-hour aggregate demand per consumer. "
            "This chart shows the exact submitted daily total evenly allocated across 24 hours for display."
        ),
    )


def build_charts(payload: dict[str, Any], scenario: ScenarioConfig) -> list[ResultChartGroup]:
    charts: list[ResultChartGroup] = [_demand_chart(scenario)]
    for _, name, block in _iter_variables(payload):
        definition = CHART_VARIABLES.get(name)
        if not definition:
            continue
        series = _series_for(block)
        if not series:
            continue
        category, label = definition
        charts.append(
            ResultChartGroup(
                key=f"variable-{name}",
                label=label,
                category=category,  # type: ignore[arg-type]
                xLabel="Hour (1-24)",
                unit=str(block.get("unit", "model units")),
                series=series,
                description=(
                    f"Source variable: {block.get('source_variable', name)}. "
                    f"{block.get('sign_description', '')}"
                ).strip(),
            )
        )
    return charts


def build_raw_table(
    payload: dict[str, Any], *, page: int, page_size: int, variable: str | None
) -> ResultTable:
    rows: list[list[str | int | float | bool | None]] = []
    for family, name, block in _iter_variables(payload):
        if variable and name != variable:
            continue
        indexes = list(block.get("index_names", []))
        for record in block.get("records", []):
            keys = record.get("keys", [])
            index_map = {
                index_name: keys[position] if position < len(keys) else None
                for position, index_name in enumerate(indexes)
            }
            rows.append(
                [
                    family,
                    name,
                    block.get("title", name),
                    block.get("unit", "model units"),
                    json.dumps(index_map, separators=(",", ":")),
                    record.get("time"),
                    float(record["value"]),
                    block.get("sign_description", ""),
                    block.get("source_variable", name),
                ]
            )
    start = (page - 1) * page_size
    window = rows[start : start + page_size]
    return ResultTable(
        key="raw-variables",
        label="Non-zero raw solver variables",
        columns=[
            "Family", "Variable", "Title", "Unit", "Indices", "Hour", "Value",
            "Sign meaning", "Source variable",
        ],
        rows=window,
        total_rows=len(rows),
        page=page,
        page_size=page_size,
        truncated=start + len(window) < len(rows),
    )


def build_results_response(
    payload: dict[str, Any],
    row: dict[str, Any],
    scenario: ScenarioConfig,
    *,
    page: int,
    page_size: int,
    variable: str | None = None,
) -> ResultsResponse:
    summary = json.loads(row["summary_json"])
    objective = summary.get("objective_value")
    termination = summary.get("termination_condition")
    if objective is None or not termination:
        raise ValueError("Completed run is missing objective or termination metadata.")
    return ResultsResponse(
        run_id=row["id"],
        solver_name="gurobi",
        termination_condition=str(termination),
        objective_value=float(objective),
        objective_label="Total hydrogen imbalance",
        objective_unit="model hydrogen units",
        solve_seconds=summary.get("solve_seconds"),
        dataset=DatasetSummary(),
        input_summary={
            "Dataset": "Johor 118 (bundled)",
            "Horizon": "24 hourly steps",
            "Selected infrastructure": len(scenario.infrastructure_ids),
            "Selected solar farms": len(scenario.solar_farm_ids),
            "Consumers": len(scenario.consumers),
            "Consumer demand (kg H2/day)": sum(
                item.demand_kg_per_day for item in scenario.consumers
            ),
            "Vehicle templates": scenario.vehicles.total(),
            "Railway enabled": scenario.railway.enabled,
        },
        charts=build_charts(payload, scenario),
        tables=[build_raw_table(payload, page=page, page_size=page_size, variable=variable)],
    )
