from __future__ import annotations

from backend.app.services.result_processor import build_charts, build_raw_table
from backend.app.services.result_serializer import VARIABLE_METADATA, serialize_variable


class Datum:
    def __init__(self, value): self.value = value


class Variable:
    name = "h2_inven"
    def items(self):
        return [(('C1', 1), Datum(2.5)), (('C1', 2), Datum(0.0)), (('C1', 3), Datum(None))]


def test_serializer_has_units_indexes_and_missing_policy():
    block = serialize_variable(Variable(), VARIABLE_METADATA["h2_inven"], 1e-9)
    assert block["unit"] == "kg H2"
    assert block["index_names"] == ["node", "hour"]
    assert block["missing_count"] == 1
    assert block["zero_omitted_count"] == 1
    assert block["records"] == [{"keys": ["C1", 1], "time": 1, "value": 2.5}]


def test_plot_and_raw_table_use_real_records(scenario):
    block = serialize_variable(Variable(), VARIABLE_METADATA["h2_inven"], 1e-9)
    payload = {"results": {"families": {"hydrogen": {"h2_inven": block}}}}
    charts = build_charts(payload, scenario)
    assert any(chart.key == "variable-h2_inven" for chart in charts)
    table = build_raw_table(payload, page=1, page_size=1, variable=None)
    assert table.rows[0][1] == "h2_inven"
    assert table.total_rows == 1


def test_every_known_variable_has_explicit_metadata():
    assert VARIABLE_METADATA
    for name, metadata in VARIABLE_METADATA.items():
        assert name and metadata.title and metadata.unit and metadata.index_names
